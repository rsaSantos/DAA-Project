# DAA-Project

Conception and optimization of machine learning models. Within the scope of DAA (Dados e Aprendizagem Automática) at Universidade do Minho.

Group MEI 13 at https://www.kaggle.com/competitions/sbstpdaa2223/overview
